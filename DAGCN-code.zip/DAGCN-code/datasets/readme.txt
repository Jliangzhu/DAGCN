
This is the main code of the paper "Domain Adaptation Graph Convolution Network for Quality Inferring of Batch Processes". 
There are 20 batch data in Penicillin and 4 batch data in IndPensim.
The data for Penicillin and IndPensim can be obtained from the following references:
[1] G. Birol, C. Undey, and A. Cinar, "A modular simulation package for fed-batch fermentation: penicillin production," Comput. Chem. Eng., vol. 11, pp. 1553−1565, 2002.
[2] S. Goldrick, A. Stefan, D. Lovett, G. Montague, and B. Lennox, "The development of an industrial-scale fed-batch fermentation simulation," J. Biotechnol., vol. 193, no. 1, pp. 70–82, 2015.
