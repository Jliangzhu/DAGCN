import torch
import torch.nn as nn
from tool import RMSE

def calculate_laplacian_with_self_loop(matrix):
    matrix = matrix + torch.eye(matrix.size(0))
    row_sum = matrix.sum(1)
    d_inv_sqrt = torch.pow(row_sum, -0.5).flatten()
    d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.0
    d_mat_inv_sqrt = torch.diag(d_inv_sqrt)
    normalized_laplacian = (
        matrix.matmul(d_mat_inv_sqrt).transpose(0, 1).matmul(d_mat_inv_sqrt)
    )
    return normalized_laplacian

class gcn(nn.Module):
    def __init__(self, in_channels, out_channels,kernel_size=1, stride=1):
        super(gcn, self).__init__()
        # pad = int((kernel_size - 1) / 2)
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=(1,kernel_size))
        self.relu = nn.ReLU()
        # self.w = nn.Linear(1,1)

    def forward(self, x, adj):
        y = self.relu((self.conv((((torch.matmul(x, adj)))))))
        return y

class GCN(nn.Module):
    def __init__(self):
        super(GCN, self).__init__()
        self.A = nn.Parameter(torch.FloatTensor(torch.rand(8, 8) + 1e-1))
        self.relu = nn.ReLU()
        self.l1 = gcn(1, 2) # dynamic matrix
        self.l2 = gcn(2, 4) # dynamic matrix
        self.fc1 = nn.Linear(32, 44)
        self.fc2 = nn.Linear(44, 44)
        self.fc3 = nn.Linear(44, 22)
        self.predict = nn.Linear(22, 1)

    def forward(self, x):
        adj = calculate_laplacian_with_self_loop(self.A)
        x1 = self.l1(x,adj)
        x2 = self.l2(x1,adj)
        x = x2.view(x2.size(0), -1)
        x = self.fc1(x)
        output_x1 = self.relu(x)
        x = self.fc2(output_x1)
        output_x2 = self.relu(x)
        x = self.fc3(output_x2)
        output_x3 = self.relu(x)
        output = self.predict(output_x3)
        return output, self.A

def target_trainGCN(epoch, batch, opt, model, target_loader):
    for t in range(epoch):
        print('epoch:', t + 1)
        for i, data in enumerate(target_loader):
            Xt = data[:,:,:,:-1].view(batch, 1, -1, 8)
            Yt = data[:,:,:,-1].view(batch, 1)
            out, adj_mat = model(Xt)
            loss = RMSE(out, Yt)
            opt.zero_grad()
            loss.backward()
            opt.step()
