import torch
import sys
import os
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

torch.set_printoptions(threshold=sys.maxsize)
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def data_norm(Data):
    min_max = MinMaxScaler()
    data = min_max.fit_transform(Data)
    return data

def loss_evaluate(y_true, y_pred):
    R2 = r2_score(y_true, y_pred)
    MAE = mean_absolute_error(y_true, y_pred)
    RMSE = np.sqrt(mean_squared_error(y_true, y_pred))
    result = np.array([R2, MAE, RMSE])
    return result

def train_TargetGCN(model, t_xtrain, t_ytrain,  epoch):
    # for name, parameters in model.named_parameters():
    #     print(name, ':', parameters.size())

    namelist = ['predict.weight', 'predict.bias','fc3.bias', 'fc3.weight', 'fc2.bias', 'fc2.weight', 'fc1.bias',
                'fc1.weight']

    for name, value in model.named_parameters():
        if name in namelist:
            value.requires_grad = True
        else:
            value.requires_grad = False

    optimizer = torch.optim.Adam(model.parameters())

    for i in range(epoch):
        prediction, adj_mat = model.forward(t_xtrain)
        Loss = RMSE(prediction, t_ytrain)
        optimizer.zero_grad()
        Loss.backward()
        optimizer.step()
        if (i % 10 == 0):
            print(i, Loss.data)

def RMSE(X,Y):
    result = torch.sqrt(torch.sum((Y-X)*(Y-X))/X.size(1))
    return result



