# -*- coding: utf-8 -*-
import sys
import os
import torch
import random
from GCN import GCN
import pandas as pd
import numpy as np
import torch.utils.data as Data
from torch import optim
from tool import RMSE, train_TargetGCN, loss_evaluate, data_norm

torch.set_printoptions(threshold=sys.maxsize)
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# Random seed
seed = 1024
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)

# Source domain
datasets_source = pd.read_excel(r"../datasets/IndPensim.xlsx",sheet_name=1)
datasets_source = datasets_source.values
datasets_source = datasets_source.reshape(-1,9)
datasets_source = np.array(datasets_source)
Source_data = datasets_source[:,:-1]
Source_label = datasets_source[:,-1].reshape(-1,1)
source_data = data_norm(Source_data)
source_label = data_norm(Source_label)

# Target domain
datasets_target = pd.read_excel("../datasets/IndPensim.xlsx",sheet_name=2)
datasets_target = datasets_target.values
datasets_target = datasets_target.reshape(-1,9)
datasets_target = np.array(datasets_target)
Target_data = datasets_target[:,:-1]
Target_label = datasets_target[:,-1].reshape(-1,1)
target_data = data_norm(Target_data)

batch = 20
epoch = 100
model = GCN()
opt = optim.Adam(model.parameters(),lr=1e-3)
model.train()

total_data = np.hstack((source_data.reshape(-1,8),source_label))
total_data = torch.tensor(total_data, dtype=torch.float32)
train_loader = Data.DataLoader(dataset=total_data,batch_size=batch,shuffle=False,drop_last=True)

print('-----------')
for t in range(epoch):
    print('epoch:',t+1)
    for i, data in enumerate(train_loader):
        print('data.shape',data.shape)
        Xs = data[:,:-1].view(batch,1,1,8)
        Ys = data[:,-1].view(batch,1)
        out, adj_mat = model(Xs)
        Ha = torch.mean(
               -adj_mat * torch.log(torch.sigmoid(adj_mat)) - (1 - adj_mat) * torch.log(1 - torch.sigmoid(adj_mat)))
        loss = RMSE(out, Ys) + 0.001*Ha
        opt.zero_grad()
        loss.backward()
        loss = loss.detach().numpy()
        print('loss', loss)
        opt.step()
        if t == epoch-1:
            torch.save(model.state_dict(), "../output/best_model.pt")

index1 = [1,100,300,700,900]
index2 = np.delete(np.arange(target_data.shape[0]), index1)
target_data = torch.tensor(target_data).unsqueeze(1).unsqueeze(1)

target_xtrain = target_data[index1, :, :, :].float()
target_xtest = target_data[index2, :, :, :].float()
Target_ytrain = Target_label[index1, :]
Target_ytest = Target_label[index2, :]

target_ytrain = data_norm(Target_ytrain)
target_ytest = data_norm(Target_ytest)
target_ytrain = torch.tensor((target_ytrain)).float()
target_ytest = torch.tensor((target_ytest)).float()

print('-----------')
model.eval()
learning_rate = 0.001
epoch = 50

train_TargetGCN(model, target_xtrain, target_ytrain, epoch)
model.eval()
target_ypred, adj_mat = model.forward(target_xtest)

DAGCN_ypred = target_ypred.detach().numpy()
DAGCN_ytest = DAGCN_ypred.reshape(-1, 1)
true_ytest = target_ytest.reshape(-1, 1)
result_DAGCN = loss_evaluate(true_ytest,DAGCN_ytest)